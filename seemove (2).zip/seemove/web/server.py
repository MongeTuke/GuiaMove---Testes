"""
web/server.py
Servidor web do SeeMove — Flask + Socket.IO
"""

import threading
import webbrowser
import time
from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["SECRET_KEY"] = "seemove-secret"
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

_state = {
    "running": False,
    "exercise": "squat",
    "cog_x": 0.0, "cog_y": 0.0,
    "total_kg": 0.0,
    "tl": 0.0, "tr": 0.0, "bl": 0.0, "br": 0.0,
    "magnitude": 0.0,
    "stability_pct": 100,
    "is_centered": True,
    "feedback": "Aguardando...",
    "severity": "ok",
    "duration_s": 0,
    "centered_pct": 0.0,
    "corrections": 0,
    "tts_log": [],
}
_state_lock = threading.Lock()


def push_state(sensor_data, cog, feedback_result, summary):
    with _state_lock:
        _state.update({
            "cog_x": cog.x,
            "cog_y": cog.y,
            "total_kg": cog.total_kg,
            "tl": round(sensor_data.top_left, 1),
            "tr": round(sensor_data.top_right, 1),
            "bl": round(sensor_data.bottom_left, 1),
            "br": round(sensor_data.bottom_right, 1),
            "magnitude": cog.magnitude,
            "stability_pct": cog.stability_pct(),
            "is_centered": cog.is_centered,
            "feedback": feedback_result.message,
            "severity": feedback_result.severity,
            "duration_s": summary.get("duration_s", 0),
            "centered_pct": summary.get("centered_pct", 0),
            "corrections": summary.get("corrections", 0),
        })
        state_copy = dict(_state)
    socketio.emit("frame", state_copy)


def push_tts(message: str, severity: str = "ok"):
    with _state_lock:
        entry = {"time": time.strftime("%M:%S"), "msg": message, "sev": severity}
        _state["tts_log"] = ([entry] + _state["tts_log"])[:20]
    socketio.emit("tts", entry)


@app.route("/")
def index():
    return render_template("dashboard.html")


@app.route("/api/state")
def api_state():
    with _state_lock:
        return jsonify(_state)


@app.route("/api/exercise/<name>", methods=["POST"])
def set_exercise(name):
    with _state_lock:
        _state["exercise"] = name
    socketio.emit("exercise_changed", {"exercise": name})
    return jsonify({"ok": True})


@socketio.on("connect")
def on_connect():
    with _state_lock:
        socketio.emit("frame", dict(_state))


def start(host="127.0.0.1", port=5000, open_browser=True):
    def _run():
        socketio.run(app, host=host, port=port, allow_unsafe_werkzeug=True)
    t = threading.Thread(target=_run, daemon=True)
    t.start()
    time.sleep(1.2)
    if open_browser:
        webbrowser.open(f"http://{host}:{port}")
    print(f"[web] Dashboard em: http://{host}:{port}")
    return t
