"""
SeeMove — ponto de entrada principal.

Uso:
    python main.py                   # simulação + dashboard no navegador
    python main.py --hardware        # Balance Board real
    python main.py --no-web          # só terminal, sem navegador
    python main.py --exercise squat  # escolhe exercício
    python main.py --report s.csv    # salva relatório ao sair
"""

import argparse
import sys
import time
from core.session import Session
from core.balance_board import BalanceBoardSimulator, BalanceBoardHardware
from audio.tts_engine import TTSEngine
from audio.sonification import SonificationEngine
from exercises.registry import ExerciseRegistry
from reports.reporter import SessionReporter
from config.settings import Settings


def parse_args():
    parser = argparse.ArgumentParser(description="SeeMove")
    parser.add_argument("--hardware", action="store_true")
    parser.add_argument("--list-devices", action="store_true")
    parser.add_argument("--exercise", type=str, default="squat",
                        choices=["squat","balance","stand","lunge"])
    parser.add_argument("--threshold", type=float, default=0.15)
    parser.add_argument("--no-tts", action="store_true")
    parser.add_argument("--no-sonification", action="store_true")
    parser.add_argument("--no-web", action="store_true")
    parser.add_argument("--report", type=str, default=None)
    return parser.parse_args()


def list_bluetooth_devices():
    try:
        import bluetooth
        print("Buscando dispositivos Bluetooth...")
        devices = bluetooth.discover_devices(lookup_names=True, duration=8)
        for addr, name in devices:
            marker = " <-- Balance Board" if "Nintendo" in name or "RVL" in name else ""
            print(f"  {addr}  |  {name}{marker}")
    except ImportError:
        print("PyBluez não instalado. Execute: pip install PyBluez")
    sys.exit(0)


def main():
    args = parse_args()
    settings = Settings(
        threshold=args.threshold,
        tts_enabled=not args.no_tts,
        sonification_enabled=not args.no_sonification,
    )

    if args.list_devices:
        list_bluetooth_devices()

    print("=" * 50)
    print("  SeeMove — Monitoramento postural")
    print("=" * 50)

    # Hardware ou simulador
    if args.hardware:
        print("\n[hardware] Conectando ao Balance Board...")
        board = BalanceBoardHardware()
        if not board.connect():
            print("[erro] Não foi possível conectar.")
            sys.exit(1)
    else:
        print("\n[simulação] Usando dados simulados.")
        board = BalanceBoardSimulator(exercise=args.exercise)

    # Áudio
    tts = TTSEngine(enabled=settings.tts_enabled)
    sonification = SonificationEngine(enabled=settings.sonification_enabled)

    # Exercício
    registry = ExerciseRegistry()
    exercise = registry.get(args.exercise)
    print(f"[exercício] {exercise.name}")

    # Relatório
    reporter = SessionReporter()

    # Dashboard web
    web_push = None
    web_tts = None
    if not args.no_web:
        try:
            from web.server import start, push_state, push_tts
            start(open_browser=True)
            web_push = push_state
            web_tts = push_tts
            print("[web] Dashboard aberto no navegador.")
        except ImportError:
            print("[web] flask/flask-socketio não instalados.")
            print("  Execute: pip install flask flask-socketio")
            print("  Continuando sem dashboard...\n")

    # Sessão
    session = Session(
        board=board,
        tts=tts,
        sonification=sonification,
        exercise=exercise,
        settings=settings,
        reporter=reporter,
        web_push=web_push,
        web_tts=web_tts,
    )

    tts.speak("SeeMove iniciado. " + exercise.start_message)
    print(f"\n[sessão] Rodando. Ctrl+C para encerrar.\n")

    try:
        session.run()
    except KeyboardInterrupt:
        print("\n\n[sessão] Encerrada.")
    finally:
        board.disconnect()
        summary = reporter.summary()
        print("\n--- Resumo ---")
        print(f"  Duração         : {summary['duration_str']}")
        print(f"  Centralizado    : {summary['centered_pct']}%")
        print(f"  Correções TTS   : {summary['corrections']}")

        if args.report:
            reporter.save_csv(args.report)

        tts.speak("Sessão encerrada.")
        print("Até logo!")


if __name__ == "__main__":
    main()
