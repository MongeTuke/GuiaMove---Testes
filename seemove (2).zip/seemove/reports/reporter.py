"""
reports/reporter.py
Registro e exportação de dados da sessão.

Armazena cada leitura com timestamp e permite exportar:
  - CSV completo (para análise pelo profissional)
  - Resumo JSON (para dashboards)
  - Relatório texto simples (para impressão)
"""

import csv
import json
import time
from dataclasses import dataclass, field
from typing import List
from core.balance_board import SensorData
from core.cog import CoGReading


@dataclass
class SessionRecord:
    """Um registro de leitura dentro da sessão."""
    timestamp: float
    tl: float
    tr: float
    bl: float
    br: float
    total_kg: float
    cog_x: float
    cog_y: float
    magnitude: float
    is_centered: bool
    stability_pct: int


class SessionReporter:
    """Coleta e exporta dados de uma sessão de exercício."""

    def __init__(self):
        self._records: List[SessionRecord] = []
        self._corrections: int = 0
        self._session_start: float = time.time()
        self._last_centered: bool = True

    def record(self, sensor_data: SensorData, cog: CoGReading):
        """Registra uma leitura de sensor + CoG."""
        rec = SessionRecord(
            timestamp=sensor_data.timestamp,
            tl=round(sensor_data.top_left, 2),
            tr=round(sensor_data.top_right, 2),
            bl=round(sensor_data.bottom_left, 2),
            br=round(sensor_data.bottom_right, 2),
            total_kg=round(cog.total_kg, 2),
            cog_x=round(cog.x, 4),
            cog_y=round(cog.y, 4),
            magnitude=round(cog.magnitude, 4),
            is_centered=cog.is_centered,
            stability_pct=cog.stability_pct(),
        )
        if self._last_centered and not cog.is_centered:
            self._corrections += 1
        self._last_centered = cog.is_centered
        self._records.append(rec)

    def summary(self) -> dict:
        """Retorna um dicionário com o resumo da sessão."""
        if not self._records:
            return {
                "duration_str": "00:00",
                "centered_pct": 0,
                "corrections": 0,
                "mean_x": 0.0,
                "mean_y": 0.0,
            }

        n = len(self._records)
        elapsed = int(time.time() - self._session_start)
        minutes, secs = divmod(elapsed, 60)
        centered_count = sum(1 for r in self._records if r.is_centered)

        mean_x = sum(r.cog_x for r in self._records) / n
        mean_y = sum(r.cog_y for r in self._records) / n
        mean_stab = sum(r.stability_pct for r in self._records) / n

        return {
            "duration_str": f"{minutes:02d}:{secs:02d}",
            "duration_s": elapsed,
            "total_readings": n,
            "centered_pct": round(centered_count / n * 100, 1),
            "corrections": self._corrections,
            "mean_x": round(mean_x, 4),
            "mean_y": round(mean_y, 4),
            "mean_stability_pct": round(mean_stab, 1),
        }

    def save_csv(self, filepath: str):
        """
        Exporta todos os registros em CSV.

        Colunas: timestamp, tl_kg, tr_kg, bl_kg, br_kg, total_kg,
                 cog_x, cog_y, magnitude, is_centered, stability_pct
        """
        fieldnames = [
            "timestamp", "tl_kg", "tr_kg", "bl_kg", "br_kg", "total_kg",
            "cog_x", "cog_y", "magnitude", "is_centered", "stability_pct",
        ]
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for r in self._records:
                writer.writerow({
                    "timestamp": r.timestamp,
                    "tl_kg": r.tl,
                    "tr_kg": r.tr,
                    "bl_kg": r.bl,
                    "br_kg": r.br,
                    "total_kg": r.total_kg,
                    "cog_x": r.cog_x,
                    "cog_y": r.cog_y,
                    "magnitude": r.magnitude,
                    "is_centered": int(r.is_centered),
                    "stability_pct": r.stability_pct,
                })
        print(f"[relatório] {len(self._records)} registros salvos em '{filepath}'")

    def save_json(self, filepath: str):
        """Exporta resumo e dados completos em JSON."""
        data = {
            "summary": self.summary(),
            "records": [
                {
                    "t": r.timestamp,
                    "x": r.cog_x,
                    "y": r.cog_y,
                    "mag": r.magnitude,
                    "stab": r.stability_pct,
                    "ok": r.is_centered,
                }
                for r in self._records
            ],
        }
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"[relatório] JSON salvo em '{filepath}'")

    def print_report(self):
        """Imprime um relatório textual no terminal."""
        s = self.summary()
        print("\n" + "=" * 45)
        print("  RELATÓRIO DE SESSÃO — SeeMove")
        print("=" * 45)
        print(f"  Duração             : {s['duration_str']}")
        print(f"  Leituras totais     : {s['total_readings']}")
        print(f"  Tempo centralizado  : {s['centered_pct']}%")
        print(f"  Estabilidade média  : {s['mean_stability_pct']}%")
        print(f"  Correções emitidas  : {s['corrections']}")
        print(f"  Desvio médio X      : {s['mean_x']:+.4f}")
        print(f"  Desvio médio Y      : {s['mean_y']:+.4f}")
        print("=" * 45)
