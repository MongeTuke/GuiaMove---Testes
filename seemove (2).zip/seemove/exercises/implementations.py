"""
exercises/implementations.py
Implementações dos exercícios suportados pelo SeeMove.

Cada exercício define:
  - Limiares específicos para desvios aceitáveis
  - Lógica de análise biomecânica adaptada ao movimento
  - Mensagens de feedback contextualizadas
"""

import math
from exercises.base import Exercise, FeedbackResult


class SquatExercise(Exercise):
    """
    Agachamento (Squat).

    Parâmetros biomecânicos:
      - Distribuição ideal: 50/50 entre pernas, levemente à frente (Y > 0)
      - Permite maior tolerância no eixo Y pois o CoG avança naturalmente
      - Detecta queda de joelho (desvio lateral excessivo)
    """

    name = "Agachamento"
    start_message = "Agachamento iniciado. Pés na largura dos ombros, olhe para frente."
    end_message = "Agachamento concluído. Bom trabalho."

    THRESHOLD_X = 0.12
    THRESHOLD_Y = 0.20   # mais tolerante no eixo Y durante o movimento

    def analyze(self, cog_x: float, cog_y: float, total_kg: float) -> FeedbackResult:
        msgs = []
        severity = "ok"

        lat = self._lateral_instruction(cog_x, self.THRESHOLD_X)
        if lat:
            msgs.append(lat)
            severity = "warn" if abs(cog_x) < self.THRESHOLD_X * 2 else "error"

        ap = self._anteroposterior_instruction(cog_y, self.THRESHOLD_Y)
        if ap:
            msgs.append(ap)
            if severity == "ok":
                severity = "warn"

        # Verifica carga mínima — usuário levantou do equipamento?
        if total_kg < 20:
            return FeedbackResult(
                "Posicione-se sobre a plataforma para iniciar",
                should_speak=True,
                severity="warn",
                cog_x=cog_x, cog_y=cog_y,
            )

        if not msgs:
            return FeedbackResult(
                "Postura correta, continue o movimento",
                should_speak=False,
                severity="ok",
                cog_x=cog_x, cog_y=cog_y,
            )

        return FeedbackResult(
            ". ".join(msgs),
            should_speak=True,
            severity=severity,
            cog_x=cog_x, cog_y=cog_y,
        )


class UnipodialBalanceExercise(Exercise):
    """
    Equilíbrio Unipodial (apoio em uma perna).

    Parâmetros biomecânicos:
      - Carga esperada em apenas um lado: 60-80% do peso total no lado dominante
      - Limiares reduzidos pois oscilações são naturais e esperadas
      - Detecta queda de quadril (Trendelenburg)
    """

    name = "Equilíbrio unipodial"
    start_message = "Equilíbrio unipodial. Eleve lentamente uma perna e mantenha."
    end_message = "Equilíbrio concluído. Excelente controle."

    THRESHOLD_X = 0.25   # desvio lateral esperado no unipodial
    THRESHOLD_Y = 0.15

    def analyze(self, cog_x: float, cog_y: float, total_kg: float) -> FeedbackResult:
        magnitude = math.sqrt(cog_x ** 2 + cog_y ** 2)
        msgs = []
        severity = "ok"

        # No unipodial, oscilações até 0.3 são aceitáveis
        if magnitude > 0.5:
            msgs.append("Desvio excessivo, retome o apoio bipodal")
            severity = "error"
        elif magnitude > 0.35:
            msgs.append("Oscilação elevada, foque em um ponto fixo à frente")
            severity = "warn"

        ap = self._anteroposterior_instruction(cog_y, self.THRESHOLD_Y)
        if ap and severity == "ok":
            msgs.append(ap)
            severity = "warn"

        if not msgs:
            if magnitude < 0.1:
                return FeedbackResult(
                    "Equilíbrio excelente, mantenha",
                    should_speak=False,
                    severity="ok",
                    cog_x=cog_x, cog_y=cog_y,
                )
            return FeedbackResult(
                "Equilíbrio dentro do esperado",
                should_speak=False,
                severity="ok",
                cog_x=cog_x, cog_y=cog_y,
            )

        return FeedbackResult(
            ". ".join(msgs),
            should_speak=True,
            severity=severity,
            cog_x=cog_x, cog_y=cog_y,
        )


class StaticPostureExercise(Exercise):
    """
    Postura Estática (bipodal parado).

    Parâmetros biomecânicos:
      - Distribuição ideal rigorosa: 50/50 em todos os eixos
      - Limiares mais estreitos pois não há movimento intencional
      - Detecta assimetrias crônicas posturais
    """

    name = "Postura estática"
    start_message = "Postura estática. Fique em pé, relaxado, olhar no horizonte."
    end_message = "Avaliação postural concluída."

    THRESHOLD_X = 0.08   # muito mais restrito
    THRESHOLD_Y = 0.10

    def analyze(self, cog_x: float, cog_y: float, total_kg: float) -> FeedbackResult:
        msgs = []
        severity = "ok"

        lat = self._lateral_instruction(cog_x, self.THRESHOLD_X)
        if lat:
            msgs.append(lat)
            severity = "warn" if abs(cog_x) < self.THRESHOLD_X * 3 else "error"

        ap = self._anteroposterior_instruction(cog_y, self.THRESHOLD_Y)
        if ap:
            msgs.append(ap)
            if severity == "ok":
                severity = "warn"

        if not msgs:
            return FeedbackResult(
                "Alinhamento correto",
                should_speak=False,
                severity="ok",
                cog_x=cog_x, cog_y=cog_y,
            )

        return FeedbackResult(
            ". ".join(msgs),
            should_speak=True,
            severity=severity,
            cog_x=cog_x, cog_y=cog_y,
        )


class LungeExercise(Exercise):
    """
    Avanço (Lunge).

    Parâmetros biomecânicos:
      - CoG se desloca significativamente para frente durante o movimento
      - Carga frontal esperada na perna que avança
      - Detecta rotação de tronco (desvio lateral excessivo)
    """

    name = "Avanço (lunge)"
    start_message = "Avanço iniciado. Pé dianteiro na frente, coluna ereta."
    end_message = "Avanços concluídos."

    THRESHOLD_X = 0.18
    THRESHOLD_Y = 0.35   # muito tolerante — o lunge é intrinsecamente assimétrico

    def analyze(self, cog_x: float, cog_y: float, total_kg: float) -> FeedbackResult:
        msgs = []
        severity = "ok"

        lat = self._lateral_instruction(cog_x, self.THRESHOLD_X)
        if lat:
            msgs.append(lat)
            severity = "warn"

        # No lunge, só alerta se for muito para trás (postura insegura)
        if cog_y < -0.40:
            msgs.append("Incline levemente o tronco para frente")
            if severity == "ok":
                severity = "warn"

        if not msgs:
            return FeedbackResult(
                "Execução correta",
                should_speak=False,
                severity="ok",
                cog_x=cog_x, cog_y=cog_y,
            )

        return FeedbackResult(
            ". ".join(msgs),
            should_speak=True,
            severity=severity,
            cog_x=cog_x, cog_y=cog_y,
        )
