"""
core/session.py
Orquestrador principal da sessão de exercício.
"""

import time
from core.balance_board import SensorData
from core.cog import calculate_cog, CoGHistory, CoGStats
from audio.tts_engine import TTSEngine
from audio.sonification import SonificationEngine
from exercises.base import Exercise
from reports.reporter import SessionReporter
from config.settings import Settings


class Session:
    def __init__(self, board, tts, sonification, exercise, settings, reporter, web_push=None, web_tts=None):
        self.board = board
        self.tts = tts
        self.sonification = sonification
        self.exercise = exercise
        self.settings = settings
        self.reporter = reporter
        self.web_push = web_push      # função para enviar frame ao dashboard
        self.web_tts = web_tts        # função para enviar log TTS ao dashboard

        self.history = CoGHistory(max_size=300)
        self.stats = CoGStats()

        self._last_tts_time = 0.0
        self._last_feedback = ""
        self._session_start = time.time()

    def run(self):
        print(f"  {'TEMPO':>8}  {'X':>7}  {'Y':>7}  {'TOTAL':>8}  STATUS")
        print("  " + "-" * 55)

        while True:
            data: SensorData = self.board.read()
            if data is None:
                continue

            cog = calculate_cog(data, threshold=self.settings.threshold)
            if cog is None:
                continue

            self.history.push(cog)
            self.stats.update(cog)
            self.reporter.record(data, cog)

            smoothed = self.history.smoothed(window=self.settings.smoothing_window)
            sx, sy = smoothed if smoothed else (cog.x, cog.y)

            feedback = self.exercise.analyze(sx, sy, cog.total_kg)
            summary = self.reporter.summary()

            # Envia para o dashboard web
            if self.web_push:
                try:
                    self.web_push(data, cog, feedback, summary)
                except Exception:
                    pass

            # Feedback de áudio com cooldown
            now = time.time()
            cooldown_ok = (now - self._last_tts_time) >= self.settings.tts_cooldown_s
            new_msg = feedback.message != self._last_feedback

            if feedback.should_speak and (cooldown_ok or new_msg):
                if self.settings.tts_enabled:
                    self.tts.speak(feedback.message)
                if self.settings.sonification_enabled:
                    self.sonification.play(sx, sy)
                if self.web_tts:
                    try:
                        self.web_tts(feedback.message, feedback.severity)
                    except Exception:
                        pass
                self._last_tts_time = now
                self._last_feedback = feedback.message

            elapsed = int(now - self._session_start)
            minutes, secs = divmod(elapsed, 60)
            status = "OK" if cog.is_centered else "CORRIGIR"
            print(f"  {minutes:02d}:{secs:02d}     {cog.x:+.3f}   {cog.y:+.3f}   "
                  f"{cog.total_kg:6.1f}kg   {status:<12}  {feedback.message}")
