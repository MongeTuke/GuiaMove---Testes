"""
core/balance_board.py
Abstração do Wii Balance Board.

Fornece duas implementações com a mesma interface:
  - BalanceBoardHardware: conecta ao hardware real via PyBluez
  - BalanceBoardSimulator: gera dados sintéticos para testes sem hardware

Protocolo:
  O Wii Balance Board se comunica como extensão de Wiimote via Bluetooth HID.
  Cada sensor retorna valores raw (16-bit unsigned) que precisam ser convertidos
  em kg usando a tabela de calibração gravada na memória do dispositivo.

Referência de endereços de memória (protocolo Wiimote):
  Calibração: 0xA40024 (12 bytes: 3 pontos × 4 sensores × 2 bytes)
  Sensores:   relatório 0x32 (extensão), bytes 0..7
"""

import struct
import time
import math
import random
from dataclasses import dataclass
from typing import Optional


@dataclass
class SensorData:
    """Leitura instantânea dos 4 sensores em quilogramas."""
    top_left: float
    top_right: float
    bottom_left: float
    bottom_right: float
    timestamp: float = 0.0

    def total(self) -> float:
        return self.top_left + self.top_right + self.bottom_left + self.bottom_right

    def as_tuple(self):
        return (self.top_left, self.top_right, self.bottom_left, self.bottom_right)


class CalibrationTable:
    """
    Tabela de calibração do Balance Board.
    Armazena 3 pontos de referência por sensor: 0 kg, 17 kg, 34 kg.
    """

    def __init__(self, raw_bytes: Optional[bytes] = None):
        # Valores padrão caso não leia da memória do dispositivo
        self.points = {
            "top_left":     [0, 1700, 3400],
            "top_right":    [0, 1700, 3400],
            "bottom_left":  [0, 1700, 3400],
            "bottom_right": [0, 1700, 3400],
        }
        if raw_bytes:
            self._parse(raw_bytes)

    def _parse(self, data: bytes):
        """
        Formato: 12 bytes, 3 pontos de calibração × 4 sensores × 2 bytes cada.
        Ordem: top_right, bottom_right, top_left, bottom_left
        """
        keys = ["top_right", "bottom_right", "top_left", "bottom_left"]
        for i, key in enumerate(keys):
            self.points[key] = [
                struct.unpack_from(">H", data, i * 2)[0],
                struct.unpack_from(">H", data, 8 + i * 2)[0],
                struct.unpack_from(">H", data, 16 + i * 2)[0],
            ]

    def raw_to_kg(self, sensor: str, raw: int) -> float:
        """Converte leitura raw de um sensor para quilogramas usando interpolação linear."""
        cal = self.points[sensor]
        if raw < cal[1]:
            low, high = cal[0], cal[1]
            ref_low, ref_high = 0.0, 17.0
        else:
            low, high = cal[1], cal[2]
            ref_low, ref_high = 17.0, 34.0

        span = high - low
        if span == 0:
            return ref_low
        return ref_low + (raw - low) / span * (ref_high - ref_low)


class BalanceBoardHardware:
    """
    Conexão real com o Wii Balance Board via Bluetooth HID (PyBluez).

    Requer:
        pip install PyBluez

    Para descobrir o endereço MAC do seu Balance Board:
        python main.py --list-devices

    Fluxo de conexão:
        1. Ativar pareamento: pressionar botão vermelho embaixo da board
        2. Criar socket L2CAP nos canais HID (17 = controle, 19 = interrupção)
        3. Enviar comando para habilitar extensões (0x04 no registro 0xA400F0)
        4. Ler calibração da memória (0xA40024)
        5. Habilitar relatório de extensão contínuo (0x32)
    """

    INTERRUPT_CHANNEL = 19
    CONTROL_CHANNEL = 17

    # Comandos do protocolo Wiimote
    CMD_SET_REPORT = 0x52
    CMD_READ_MEM = 0x17
    CMD_WRITE_MEM = 0x16

    # Registros de memória
    REG_EXTENSION_INIT1 = 0xA400F0
    REG_EXTENSION_INIT2 = 0xA400FB
    REG_CALIBRATION = 0xA40024

    def __init__(self, address: Optional[str] = None):
        self.address = address
        self.calibration = CalibrationTable()
        self._ctrl_sock = None
        self._intr_sock = None
        self._connected = False

    def discover(self) -> Optional[str]:
        """Procura o Balance Board via Bluetooth e retorna o endereço MAC."""
        try:
            import bluetooth
            devices = bluetooth.discover_devices(lookup_names=True, duration=8)
            for addr, name in devices:
                if "Nintendo" in name or "RVL-WBC" in name:
                    return addr
        except ImportError:
            raise RuntimeError("PyBluez não instalado. Execute: pip install PyBluez")
        return None

    def connect(self) -> bool:
        """
        Estabelece conexão com o Balance Board.
        Retorna True se bem-sucedido, False caso contrário.
        """
        try:
            import bluetooth

            if not self.address:
                print("[bluetooth] Buscando Balance Board...")
                self.address = self.discover()
                if not self.address:
                    print("[bluetooth] Dispositivo não encontrado.")
                    return False

            print(f"[bluetooth] Conectando a {self.address}...")

            self._ctrl_sock = bluetooth.BluetoothSocket(bluetooth.L2CAP)
            self._intr_sock = bluetooth.BluetoothSocket(bluetooth.L2CAP)

            self._ctrl_sock.connect((self.address, self.CONTROL_CHANNEL))
            self._intr_sock.connect((self.address, self.INTERRUPT_CHANNEL))
            self._intr_sock.setblocking(False)

            # Inicializa a extensão (desativa criptografia)
            self._write_register(self.REG_EXTENSION_INIT1, b"\x55")
            time.sleep(0.1)
            self._write_register(self.REG_EXTENSION_INIT2, b"\x00")
            time.sleep(0.1)

            # Lê calibração
            cal_raw = self._read_register(self.REG_CALIBRATION, 24)
            if cal_raw:
                self.calibration = CalibrationTable(cal_raw)

            # Habilita relatório de extensão contínuo
            self._set_report_mode(0x32)

            self._connected = True
            print(f"[bluetooth] Conectado! Calibração carregada.")
            return True

        except Exception as e:
            print(f"[bluetooth] Erro na conexão: {e}")
            return False

    def _write_register(self, address: int, data: bytes):
        """Escreve dados em um registrador do Wiimote."""
        if not self._ctrl_sock:
            return
        payload = struct.pack(">BI3s", 0x04, address, data.ljust(16, b"\x00")[:16])
        self._ctrl_sock.send(bytes([self.CMD_SET_REPORT, self.CMD_WRITE_MEM]) + payload)

    def _read_register(self, address: int, size: int) -> Optional[bytes]:
        """Lê dados de um registrador do Wiimote (simplificado)."""
        # Implementação completa requer tratar resposta 0x21 (read data)
        # Para o projeto completo, use a biblioteca 'xwiimote' ou 'cwiid'
        return None

    def _set_report_mode(self, mode: int):
        """Configura o modo de relatório do Wiimote."""
        if not self._ctrl_sock:
            return
        self._ctrl_sock.send(bytes([self.CMD_SET_REPORT, 0x12, 0x04, mode]))

    def _parse_extension(self, data: bytes) -> SensorData:
        """
        Extrai leituras dos 4 sensores de pressão do relatório de extensão.
        Formato do relatório 0x32: bytes 4..11 contêm os sensores.
        Ordem: top_right (2B), bottom_right (2B), top_left (2B), bottom_left (2B)
        """
        if len(data) < 12:
            return SensorData(0, 0, 0, 0, time.time())

        raw_tr, raw_br, raw_tl, raw_bl = struct.unpack_from(">HHHH", data, 4)
        return SensorData(
            top_left=self.calibration.raw_to_kg("top_left", raw_tl),
            top_right=self.calibration.raw_to_kg("top_right", raw_tr),
            bottom_left=self.calibration.raw_to_kg("bottom_left", raw_bl),
            bottom_right=self.calibration.raw_to_kg("bottom_right", raw_br),
            timestamp=time.time(),
        )

    def read(self) -> Optional[SensorData]:
        """
        Lê o próximo pacote de dados do Balance Board.
        Retorna None se não houver dados disponíveis.
        """
        if not self._connected or not self._intr_sock:
            return None
        try:
            data = self._intr_sock.recv(25)
            if len(data) >= 2 and data[1] == 0x32:
                return self._parse_extension(data)
        except Exception:
            pass
        return None

    def disconnect(self):
        """Encerra a conexão Bluetooth."""
        self._connected = False
        for sock in (self._ctrl_sock, self._intr_sock):
            if sock:
                try:
                    sock.close()
                except Exception:
                    pass
        print("[bluetooth] Desconectado.")


class BalanceBoardSimulator:
    """
    Simulador do Balance Board para desenvolvimento sem hardware.

    Gera padrões de pressão realistas para cada tipo de exercício,
    incluindo ruído gaussiano para simular instabilidades naturais.
    """

    PATTERNS = {}  # preenchido após definição das funções abaixo

    def __init__(self, exercise: str = "squat", sample_rate: float = 0.1):
        self.exercise = exercise
        self.sample_rate = sample_rate
        self._tick = 0
        self._connected = False

    def connect(self) -> bool:
        self._connected = True
        print(f"[simulador] Iniciado para exercício: {self.exercise}")
        return True

    def read(self) -> SensorData:
        """Gera leitura simulada e aguarda o intervalo de amostragem."""
        time.sleep(self.sample_rate)
        self._tick += 1
        pattern_fn = self.PATTERNS.get(self.exercise, _stand_pattern)
        tl, tr, bl, br = pattern_fn(self._tick)
        return SensorData(
            top_left=max(0.0, tl),
            top_right=max(0.0, tr),
            bottom_left=max(0.0, bl),
            bottom_right=max(0.0, br),
            timestamp=time.time(),
        )

    def disconnect(self):
        self._connected = False
        print("[simulador] Encerrado.")


# Padrões de simulação — funções puras para facilitar testes unitários

def _squat_pattern(t: int):
    """Agachamento: oscilação ântero-posterior e leve desvio lateral."""
    noise = lambda: random.gauss(0, 1.5)
    tl = 18 + math.sin(t * 0.08) * 6 + noise()
    tr = 17 + math.sin(t * 0.08 + 0.3) * 6 + noise()
    bl = 15 + math.cos(t * 0.08) * 4 + noise()
    br = 20 + math.sin(t * 0.05) * 5 + noise()
    return tl, tr, bl, br


def _balance_pattern(t: int):
    """Equilíbrio unipodal: carga concentrada no lado direito com oscilações maiores."""
    noise = lambda: random.gauss(0, 2.5)
    tl = 5 + math.sin(t * 0.12) * 4 + noise()
    tr = 30 + math.sin(t * 0.09) * 8 + noise()
    bl = 4 + math.cos(t * 0.11) * 3 + noise()
    br = 31 + math.cos(t * 0.07) * 7 + noise()
    return tl, tr, bl, br


def _stand_pattern(t: int):
    """Postura estática: distribuição equilibrada com ruído mínimo."""
    noise = lambda: random.gauss(0, 0.8)
    return 17 + noise(), 18 + noise(), 17 + noise(), 18 + noise()


def _lunge_pattern(t: int):
    """Avanço (lunge): carga frontal e lateral assimétrica."""
    noise = lambda: random.gauss(0, 2.0)
    tl = 25 + math.sin(t * 0.06) * 10 + noise()
    tr = 10 + math.sin(t * 0.06 + math.pi) * 5 + noise()
    bl = 15 + math.cos(t * 0.05) * 8 + noise()
    br = 8 + math.cos(t * 0.05 + math.pi) * 4 + noise()
    return tl, tr, bl, br


# Registra padrões na classe depois de defini-los
BalanceBoardSimulator.PATTERNS = {
    "squat": _squat_pattern,
    "balance": _balance_pattern,
    "stand": _stand_pattern,
    "lunge": _lunge_pattern,
}
